/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;
import Utils.MyConnection;
import entities.CodePromo;
import entities.User;
import entities.UserRole;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.ICodePromoCRUD;
import entities.CodePromo;
import entities.User;
import entities.Evenement;
/**
 *
 * @author ghofr
 */
  public class CodePromoCRUD {
    private Connection cnx = MyConnection.getInstance().getCnx();

    public CodePromoCRUD() {
        // Initialisez votre connexion à la base de données ici (comme vous l'avez fait dans UserCRUD)
        // Assurez-vous d'initialiser correctement votre connexion.
    }

    public void ajouterCodePromo(CodePromo codePromo) {
        try {
            String requete = "INSERT INTO codepromo (code, description, valeur, estvalide) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1, codePromo.getCode());
            pst.setString(2 , codePromo.getDescription());
            pst.setDouble(3, codePromo.getValeur());
            pst.setBoolean(4, codePromo.isEstValide());
            pst.executeUpdate();
            System.out.println("Code Promo ajouté avec succès !");
        } catch (SQLException ex) {
            // Gérez les erreurs ici
            System.out.println(ex.getMessage());
        }
    }

    public void modifierCodePromo(CodePromo codePromo) {
        try {
            String requete = "UPDATE codepromo SET code=?, description=? , valeur=?, estvalide=? WHERE idcp=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1, codePromo.getCode());
            pst.setString(2 , codePromo.getDescription());
            pst.setDouble(3, codePromo.getValeur());
            pst.setBoolean(4, codePromo.isEstValide());
            pst.setInt(5, codePromo.getIdcp());
            pst.executeUpdate();
            System.out.println("Code Promo modifié avec succès !");
        } catch (SQLException ex) {
            // Gérez les erreurs ici
            System.out.println(ex.getMessage());
        }
    }

    public void supprimerCodePromo(int idcp) {
        try {
            String requete = "DELETE FROM codepromo WHERE idcp = ?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, idcp);
            pst.executeUpdate();
            System.out.println("Code Promo supprimé avec succès !");
        } catch (SQLException ex) {
            // Gérez les erreurs ici
            System.out.println(ex.getMessage());
        }
    }

    public CodePromo rechercherCodePromoParId(int idcp) {
        try {
        String requete = "SELECT * FROM codepromo WHERE idcp = ?";
        PreparedStatement pst = cnx.prepareStatement(requete);
        pst.setInt(1, idcp);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            CodePromo codePromo = new CodePromo();
            codePromo.setIdcp(rs.getInt("idcp"));
            codePromo.setCode(rs.getString("code"));
            codePromo.setCode(rs.getString("description"));
            codePromo.setValeur(rs.getDouble("valeur"));
            codePromo.setEstValide(rs.getBoolean("estvalide"));
            return codePromo;
        }
    } catch (SQLException ex) {
        // Gérez les erreurs ici
        System.out.println(ex.getMessage());
    }
    return null;
    }

    public List<CodePromo> rechercherTousLesCodesPromo() {
        List<CodePromo> codesPromo = new ArrayList<>();
        try {
            String requete = "SELECT * FROM codepromo";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                CodePromo codePromo = new CodePromo();
                codePromo.setIdcp(rs.getInt("idcp"));
                codePromo.setCode(rs.getString("code"));
                codePromo.setCode(rs.getString("description"));
                codePromo.setValeur(rs.getDouble("valeur"));
                codePromo.setEstValide(rs.getBoolean("estvalide"));
                codesPromo.add(codePromo);
            }
        } catch (SQLException ex) {
            // Gérez les erreurs ici
            System.out.println(ex.getMessage());
        }
        return codesPromo;
    } 
}
