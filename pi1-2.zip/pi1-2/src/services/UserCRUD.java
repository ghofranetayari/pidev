/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;
import entities.User; // Assurez-vous d'importer la classe User depuis le package entites
import Utils.MyConnection; // Assurez-vous d'importer la classe MyConnection
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.IUserCRUD;
import java.sql.*;
import java.sql.ResultSet;
import entities.UserRole;
import java.util.ArrayList;
import java.util.List;
import entities.CodePromo;

import entities.Evenement;
/**
 *

    @Override
    
 * @author ghofr
 */

    
    public class UserCRUD implements IUserCRUD <User>  {
         private Connection cnx = MyConnection.getInstance().getCnx();
public UserCRUD () {

}
    
    public void ajouterUtilisateur(User t) {
        
try {
    String requete = "INSERT INTO user (nom, prenom, email, motDePasse, numeroTelephone, dateNaissance, genre , role) VALUES (?, ?, ?, ?, ?, ?, ? , ?)";
    PreparedStatement pst = cnx.prepareStatement(requete);
    pst.setString(1, t.getNom());
    pst.setString(2, t.getPrenom());
    pst.setString(3, t.getEmail());
    pst.setString(4, t.getMotDePasse());
    pst.setString(5, t.getNumeroTelephone());
    pst.setString(6, t.getDateNaissance());
    pst.setString(7, t.getGenre());
    pst.setString(8, t.getRole().toString());
    pst.executeUpdate();
    System.out.println("Utilisateur ajouté avec succès !");
} catch (SQLException ex) {
    Logger.getLogger(UserCRUD.class.getName()).log(Level.SEVERE, null, ex);
    System.out.println(ex.getMessage());
}

        
}
    public void modifierUtilisateur(User t) {
        try {
            String requete = "UPDATE user SET nom=?, prenom=?, email=?, motDePasse=?, numeroTelephone=?, dateNaissance=?, genre=? WHERE id=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1, t.getNom());
            pst.setString(2, t.getPrenom());
            pst.setString(3, t.getEmail());
            pst.setString(4, t.getMotDePasse());
            pst.setString(5, t.getNumeroTelephone());
            pst.setString(6, t.getDateNaissance());
            pst.setString(7, t.getGenre());
            pst.setString(8, t.getRole().toString());
            pst.setInt(9, t.getId()); // Assurez-vous d'avoir un ID valide pour l'utilisateur que vous voulez modifier
            pst.executeUpdate();
            System.out.println("Utilisateur modifié avec succès !");
        } catch (SQLException ex) {
            Logger.getLogger(UserCRUD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
    }
    
    
   public User rechercherUtilisateurParId(int id) {
    try {
        String requete = "SELECT * FROM user WHERE id = ?";
        PreparedStatement pst = cnx.prepareStatement(requete);
        pst.setInt(1, id);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            User utilisateur = new User();
            utilisateur.setId(rs.getInt("id"));
            utilisateur.setNom(rs.getString("nom"));
            utilisateur.setPrenom(rs.getString("prenom"));
            utilisateur.setEmail(rs.getString("email"));
            utilisateur.setMotDePasse(rs.getString("motDePasse"));
            utilisateur.setNumeroTelephone(rs.getString("numeroTelephone"));
            utilisateur.setDateNaissance(rs.getString("dateNaissance"));
            utilisateur.setGenre(rs.getString("genre"));
            utilisateur.setRole(UserRole.valueOf(rs.getString("role"))); // Récupérez le rôle
            return utilisateur;
        }
    } catch (SQLException ex) {
        Logger.getLogger(UserCRUD.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println(ex.getMessage());
    }
    return null; // Retournez null si l'utilisateur n'a pas été trouvé
} 
    
    
    public void supprimerUtilisateur(int id) {
    try {
        String requete = "DELETE FROM user WHERE id = ?";
        PreparedStatement pst = cnx.prepareStatement(requete);
        pst.setInt(1, id);
        int rowsDeleted = pst.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("Utilisateur supprimé avec succès !");
        } else {
            System.out.println("L'utilisateur avec l'ID " + id + " n'a pas été trouvé.");
        }
    } catch (SQLException ex) {
        Logger.getLogger(UserCRUD.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println(ex.getMessage());
    }
}
    public List<User> rechercherTousLesUtilisateurs() {
    List<User> utilisateurs = new ArrayList<>();
    try {
        String requete = "SELECT * FROM user";
        Statement stmt = cnx.createStatement();
        ResultSet rs = stmt.executeQuery(requete);
        while (rs.next()) {
            User utilisateur = new User();
            utilisateur.setId(rs.getInt("id"));
            utilisateur.setNom(rs.getString("nom"));
            utilisateur.setPrenom(rs.getString("prenom"));
            utilisateur.setEmail(rs.getString("email"));
            utilisateur.setMotDePasse(rs.getString("motDePasse"));
            utilisateur.setNumeroTelephone(rs.getString("numeroTelephone"));
            utilisateur.setDateNaissance(rs.getString("dateNaissance"));
            utilisateur.setGenre(rs.getString("genre"));
            utilisateur.setRole(UserRole.valueOf(rs.getString("role")));
            utilisateurs.add(utilisateur);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UserCRUD.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println(ex.getMessage());
    }
    return utilisateurs;
}

    
    
    
    }



    

    
    

