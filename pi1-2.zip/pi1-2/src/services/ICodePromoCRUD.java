/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.CodePromo;
import java.util.List;
import services.CodePromoCRUD;
/**
 *
 * @author ghofr
 */
public interface ICodePromoCRUD <CodePromoutilisateur> {
  void ajouterCodePromo(CodePromo codePromo);
    void modifierCodePromo(CodePromo codePromo);
    void supprimerCodePromo(int idcp);
    CodePromo rechercherCodePromoParId(int idcp);
    List<CodePromo> rechercherTousLesCodesPromo();  
}
