/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.User;
import java.util.List;
import services.UserCRUD;
import Utils.MyConnection;
/**
 *
 * @author ghofr
 */
public interface IUserCRUD <utilisateur> {
     public void ajouterUtilisateur(User t);
     public void modifierUtilisateur (User t);
     public User rechercherUtilisateurParId(int id);
     public void supprimerUtilisateur(int id); // Ajoutez cette méthode pour supprimer un utilisateur
     public List<User> rechercherTousLesUtilisateurs();

     
     /* User recupererUtilisateur(int id);
    List<User> recupererTousLesUtilisateurs();
    void mettreAJourUtilisateur(User utilisateur);
    void supprimerUtilisateur(int id);*/
}
