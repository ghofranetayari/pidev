/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;
import entities.CodePromo;
import entities.Evenement;
import entities.User;
import entities.UserRole;
import services.UserCRUD;
import entities.User;
import Utils.MyConnection;
import entities.Evenement;
import java.sql.SQLException;
import services.IUserCRUD;
import entities.UserRole;
import java.util.List;
import entities.Evenement;
import entities.Participation;
/**
 *
 * @author ghofr
 */
public class Main {
   public static void main(String[] args) {
        // Créer un utilisateur
        User user = new User("Nom", "Prénom", "utilisateur@example.com", "motdepasse", "1234567890", "01-01-2000", "Homme", UserRole.CLIENT);

        // Créer des événements
        Evenement evenement1 = new Evenement("Événement 1");
        Evenement evenement2 = new Evenement("Événement 2");
        Evenement evenement3 = new Evenement("Événement 3");
        Evenement evenement4 = new Evenement("Événement 4");

        // Réserver des événements par l'utilisateur
        user.reserverEvenement(evenement1);
        user.reserverEvenement(evenement2);
        user.reserverEvenement(evenement3);
        user.reserverEvenement(evenement4);
        

        // Vérifier le nombre de réservations
        int nombreDeReservations = user.getReservations().size();

        // Vérifier si un code promo a été généré
        if (nombreDeReservations >= User.SEUIL_RESERVATIONS_POUR_CODE_PROMO) {
            CodePromo codePromo = user.getCodePromo();
            System.out.println("Code Promo généré : " + codePromo.getCode());
        }
    } 
}
