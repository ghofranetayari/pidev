/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import entities.Evenement;
import entities.User;
import services.UserCRUD;

import Utils.MyConnection;
import entities.Evenement;
import java.sql.SQLException;
import services.IUserCRUD;
import entities.UserRole;
import java.util.List;

import entities.Participation;
/**
 *
 * @author ghofr
 */
public class UserTest {

    public static void main(String[] args) {
        User utilisateur = new User("ghof", "Prénom", "email@example.com", "motdepasse");

        Evenement evenement1 = new Evenement("Événement 1");
        Evenement evenement2 = new Evenement("Événement 2");
        Evenement evenement3 = new Evenement("Événement 3");
        
        
        utilisateur.reserverEvenement(evenement1);
        utilisateur.reserverEvenement(evenement2);
        utilisateur.reserverEvenement(evenement3);
        

      //  Evenement evenement3 = new Evenement("Événement 3");
        utilisateur.reserverEvenement(evenement3);

        // Vérifiez si un code promo a été généré après la réservation du troisième événement
        if (utilisateur.getCodePromo() != null) {
            System.out.println("Le code promo a été généré automatiquement : " + utilisateur.getCodePromo().getCode());
        } else {
            System.out.println("Le code promo n'a pas été généré automatiquement.");
        }

        Evenement evenement4 = new Evenement("Événement 4");
        utilisateur.reserverEvenement(evenement4);

        // Vérifiez à nouveau si un code promo a été généré après la réservation du quatrième événement
        if (utilisateur.getCodePromo() != null) {
            System.out.println("Le code promo a été généré automatiquement : " + utilisateur.getCodePromo().getCode());
        } else {
            System.out.println("Le code promo n'a pas été généré automatiquement.");
        }
    }
}
 

