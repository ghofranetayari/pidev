/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author ghofr
 */
public class User {
   
   private int id;
    private String nom;
    private String prenom;
    private String email;
    private String motDePasse;
    private String numeroTelephone;
    private String dateNaissance;
    private String genre;
    private UserRole role ;
    private CodePromo codePromo;
    private int utilisationsCodePromo;
  public static final int SEUIL_RESERVATIONS_POUR_CODE_PROMO = 3;
    // Constructeur par défaut
    public User() {
    }

    // Constructeur avec les attributs d'authentification
    public User(String nom, String prenom, String email, String motDePasse) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.motDePasse = motDePasse;
    }

    // Constructeur avec tous les attributs
    public User(String nom, String prenom, String email, String motDePasse, String numeroTelephone, String dateNaissance, String genre , UserRole role) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.motDePasse = motDePasse;
        this.numeroTelephone = numeroTelephone;
        this.dateNaissance = dateNaissance;
        this.genre = genre;
        this.role = role ;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getNumeroTelephone() {
        return numeroTelephone;
    }

    public void setNumeroTelephone(String numeroTelephone) {
        this.numeroTelephone = numeroTelephone;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public CodePromo getCodePromo() {
        return codePromo;
    }

    public void setCodePromo(CodePromo codePromo) {
        this.codePromo = codePromo;
    }

    public int getUtilisationsCodePromo() {
        return utilisationsCodePromo;
    }

    public void setUtilisationsCodePromo(int utilisationsCodePromo) {
        this.utilisationsCodePromo = utilisationsCodePromo;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", motDePasse=" + motDePasse + ", numeroTelephone=" + numeroTelephone + ", dateNaissance=" + dateNaissance + ", genre=" + genre + ", role=" + role + ", codePromo=" + codePromo + ", utilisationsCodePromo=" + utilisationsCodePromo + '}';
    }
/****************************************/
    private List<Evenement> reservations = new ArrayList<>();
  
    
    
    
    public List<Evenement> getReservations() {
        return reservations;
    }
   
   

   
    public void reserverEvenement(Evenement evenement) {
        reservations.add(evenement);
    // Logique pour réserver un événement
    // Assurez-vous d'ajouter cet événement à la liste des réservations de l'utilisateur

    if (this.getReservations().size() >= SEUIL_RESERVATIONS_POUR_CODE_PROMO) {
        // Générez automatiquement un code promo
        CodePromo nouveauCodePromo = genererCodePromo(); // Appel à une méthode de génération de code promo

        // Attribuez le nouveau code promo à l'utilisateur
        this.setCodePromo(nouveauCodePromo);

        // Réinitialisez le compteur d'utilisations de code promo
        this.setUtilisationsCodePromo(0);
    }
}

public CodePromo genererCodePromo() {
    CodePromo codePromo = new CodePromo();
    codePromo.setCode(genererCodeUnique()); // Logique pour générer un code unique
    codePromo.setDescription("Description du code promo");
    codePromo.setValeur(20.0); // Par exemple, 20% de réduction
    codePromo.setEstValide(true);

    return codePromo;
}

private String genererCodeUnique() {
    // Logique pour générer un code unique (par exemple, combinaison de lettres et de chiffres aléatoires)
    return "NOUVEAU_CODE_UNIQUE";
}


    
    
}


     

 

