/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import entities.CodePromo;
import entities.User;
import entities.Evenement;
/**
 *
 * @author ghofr
 */
public class Participation {
    
    private int idpar; // ID unique de la participation
    private int userId; // ID de l'utilisateur
    private int evenementId; // ID de l'événement

    // Constructeurs, getters, setters
    // Vous pouvez ajouter d'autres attributs selon les besoins

    public Participation() {
    }

    public Participation(int idpar, int userId, int evenementId) {
        this.idpar = idpar;
        this.userId = userId;
        this.evenementId = evenementId;
    }

    public int getIdpar() {
        return idpar;
    }

    public void setIdpar(int idpar) {
        this.idpar = idpar;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getEvenementId() {
        return evenementId;
    }

    public void setEvenementId(int evenementId) {
        this.evenementId = evenementId;
    }

    @Override
    public String toString() {
        return "Participation{" + "idpar=" + idpar + ", userId=" + userId + ", evenementId=" + evenementId + '}';
    }

}


