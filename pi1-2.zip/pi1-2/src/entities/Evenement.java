 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import entities.CodePromo;
import entities.User;
import entities.Participation;
/**
 *
 * @author ghofr
 */
public class Evenement {
    private int idEvenement;
    private String titre;
    private String description;
    private String date_depart;
    private String durée;
    private float prix;
    private String catégorie;
    private int guide_id;
    private String destination;
    private String image;

    // Constructeurs, getters et setters
    

    public Evenement() {
        // Constructeur par défaut
    }

    public Evenement(String titre) {
        this.titre = titre;
    }

    public Evenement(int idEvenement, String titre, String description, String date_depart, String durée, float prix, String catégorie, int guide_id, String destination, String image) {
        this.idEvenement = idEvenement;
        this.titre = titre;
        this.description = description;
        this.date_depart = date_depart;
        this.durée = durée;
        this.prix = prix;
        this.catégorie = catégorie;
        this.guide_id = guide_id;
        this.destination = destination;
        this.image = image;
    }
    

    // Vous pouvez ajouter ici les constructeurs avec paramètres si nécessaire

    public int getIdEvenement() {
        return idEvenement;
    }

    public void setIdEvenement(int idEvenement) {
        this.idEvenement = idEvenement;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate_depart() {
        return date_depart;
    }

    public void setDate_depart(String date_depart) {
        this.date_depart = date_depart;
    }

    public String getDurée() {
        return durée;
    }

    public void setDurée(String durée) {
        this.durée = durée;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public String getCatégorie() {
        return catégorie;
    }

    public void setCatégorie(String catégorie) {
        this.catégorie = catégorie;
    }

    public int getGuide_id() {
        return guide_id;
    }

    public void setGuide_id(int guide_id) {
        this.guide_id = guide_id;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
