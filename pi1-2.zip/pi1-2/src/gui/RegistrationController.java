/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Utils.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.scene.control.DatePicker;

/**
 * FXML Controller class
 *
 * @author ghofr
 */
public class RegistrationController implements Initializable {

    @FXML
    private TextField pnom;
    @FXML
    private TextField pprenom;
    @FXML
    private TextField pemail;
    @FXML
    private TextField pmotdepasse;
    @FXML
    private TextField pconfirmmotdepasse;
    @FXML
    private TextField pnumerotelephone;
    @FXML
    private ComboBox pgenre;
    @FXML
    private RadioButton pclient;
    @FXML
    private RadioButton pguide;
    @FXML
    private Button pbtnRegister;
    @FXML
    private Label pErrorMessage;
    @FXML
    private DatePicker pdatenaissance;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       ObservableList<String> liste = FXCollections.observableArrayList("Homme", "Femme");
pgenre.setItems(liste);
    }  
    private void handleRegisterButtonAction() throws IOException {
        String password = pmotdepasse.getText();
    String confirmPassword = pconfirmmotdepasse.getText();

    if (password.equals(confirmPassword)) {
        MyConnection myConnection = MyConnection.getInstance();
        Connection connection = myConnection.getCnx();

       String nom = pnom.getText();
String prenom = pprenom.getText();
String email = pemail.getText();
String motdepasse = pmotdepasse.getText();
String numerotelephone = pnumerotelephone.getText();
String datenaissance = pdatenaissance.getValue().toString(); // Conversion de DatePicker en String
String genre = pgenre.getValue().toString(); // Conversion de ComboBox en String

boolean estClient = pclient.isSelected();
boolean estGuide = pguide.isSelected();


Connection cnx = myConnection.getCnx();

try {
    String sql = "INSERT INTO Utilisateurs (nom, prenom, email, motdepasse, numerotelephone, datenaissance, genre, estClient, estGuide) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    PreparedStatement statement = connection.prepareStatement(sql);
    statement.setString(1, nom);
    statement.setString(2, prenom);
    statement.setString(3, email);
    statement.setString(4, motdepasse);
    statement.setString(5, numerotelephone);
    statement.setString(6, datenaissance);
    statement.setString(7, genre);
    statement.setBoolean(8, estClient);
    statement.setBoolean(9, estGuide);
    
    int rowsAffected = statement.executeUpdate();
    
    if (rowsAffected > 0) {
        System.out.println("Enregistrement réussi.");
    } else {
        System.out.println("Échec de l'enregistrement.");
    }
} catch (SQLException ex) {
    ex.printStackTrace();
}

    } else {
        // Les mots de passe ne correspondent pas, afficher un message d'erreur.
        pErrorMessage.setText("Les mots de passe ne correspondent pas.");
    }
}
      
}

