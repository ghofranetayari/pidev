/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import entities.CodePromo;
import services.CodePromoCRUD;
import services.ICodePromoCRUD;
import Utils.MyConnection;
import entities.User;
import java.util.List;
import services.UserCRUD;


/**
 *
 * @author ghofr
 */
public class MainCodePromo {
 
    // Création d'une instance de CodePromoCRUD
     //   CodePromo codePromo = new CodePromo();
        
    private static CodePromo CodePromoutilisateur ;
    
  public static void main(String[] args)  {
        CodePromoutilisateur  = new CodePromo();
        CodePromoCRUD codePromoCRUD = new CodePromoCRUD();

        // Créer un code promo à ajouter
   /*     CodePromo codePromo = new CodePromo();
       // codePromo.setCode("PROMO123");
        codePromo.setDescription("Réduction de 1000%");
        codePromo.setValeur(20.0); // Par exemple, 20.0 pour 20%
        codePromo.setEstValide(true); // Par exemple, le code promo est valide

        codePromoCRUD.ajouterCodePromo(codePromo);
        System.out.println("Code promo ajouté avec succès!");  */

        // rechercher CodePromoparID
  /* int idCodePromoARechercher = 2; // Remplacez par l'ID du code promo que vous recherchez
        CodePromo codePromoRecherche = codePromoCRUD.rechercherCodePromoParId(idCodePromoARechercher);
        if (codePromoRecherche != null) {
            System.out.println("Code promo trouvé : " + codePromoRecherche.toString());
        } else {
            System.out.println("Code promo non trouvé.");
        }
  //modifier CodePromo
 /* int idCodePromoAModifier = 1; // Remplacez par l'ID du code promo que vous souhaitez modifier
        CodePromo codePromoModifier = codePromoCRUD.rechercherCodePromoParId(idCodePromoAModifier);
        if (codePromoModifier != null) {
            codePromoModifier.setCode("NOUVEAUCODE");
            codePromoModifier.setDescription("Nouvelle description");
            codePromoModifier.setValeur(30.0);
            codePromoModifier.setEstValide(true);

            codePromoCRUD.modifierCodePromo(codePromoModifier);
            System.out.println("Code promo modifié avec succès !");
        } else {
            System.out.println("Code promo non trouvé.");
        }
  
  
  
  
  
  // supprimer CodePromo  
    int idCodePromoASupprimer = 1; // Remplacez par l'ID du code promo que vous souhaitez supprimer
    codePromoCRUD.supprimerCodePromo(idCodePromoASupprimer);
    System.out.println("Code promo supprimé avec succès !"); 
  
  //rechercher tous les CodePromo
   List<CodePromo> tousLesCodesPromo = codePromoCRUD.rechercherTousLesCodesPromo();
for (CodePromo code : tousLesCodesPromo) {
    System.out.println("Code promo trouvé : " + code.toString());
}*/

  }
}
