/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ghofr
 */
public class SignController implements Initializable {

    @FXML
    private TextField femail;
    @FXML
    private PasswordField fpassword;
    @FXML
    private Button flogin;
    @FXML
    private Label fsignup;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Vous pouvez ajouter des initialisations ou des actions ici si nécessaire
    }

private boolean isValidUser(String email, String password) {
        // Remplacez ces valeurs par les véritables informations d'utilisateur attendues
        String userExpectedEmail = "utilisateur@example.com";
        String userExpectedPassword = "motdepasse";

        // Vérifiez si l'e-mail et le mot de passe correspondent aux valeurs attendues
        return email.equals(userExpectedEmail) && password.equals(userExpectedPassword);
    }
    @FXML
   
private void handleLoginButtonAction(ActionEvent event) throws IOException {
    // C'est le gestionnaire d'événements pour le bouton de connexion
    String email = femail.getText();
    String password = fpassword.getText();

    // Vérifier les informations d'authentification et effectuer la connexion
    if (isValidUser(email, password)) {
        // L'utilisateur est authentifié avec succès, chargez la nouvelle scène TableView.fxml
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TableView.fxml"));
        Parent tableView = loader.load();
        Scene tableViewScene = new Scene(tableView);
        // Obtenez la fenêtre actuelle et remplacez sa scène par la nouvelle scène
        Stage stage = (Stage) flogin.getScene().getWindow();
        stage.setScene(tableViewScene);
    } else {
        // Afficher un message d'erreur si l'authentification échoue
        fsignup.setText("Identifiants incorrects. Veuillez réessayer.");
    }
}
}


    