package gui;

import entities.User;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import entities.UserRole;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import services.UserCRUD;

public class RegistrationController implements Initializable {

    @FXML
    private TextField pnom;
    @FXML
    private TextField pprenom;
    @FXML
    private TextField pemail;
    @FXML
    private TextField pmotdepasse;
    @FXML
    private TextField pconfirmmotdepasse;
    @FXML
    private TextField pnumerotelephone;
    @FXML
    private ComboBox<String> pgenre;
    @FXML
    private RadioButton pclient;
    @FXML
    private RadioButton pguide;
    @FXML
    private Label pErrorMessage;
@FXML
private Button pbtnRegister;
    private UserCRUD userCRUD = new UserCRUD();  // Instantiate UserCRUD for database operations

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> genres = FXCollections.observableArrayList("Homme", "Femme");
        pgenre.setItems(genres);
    }

    @FXML
    private void registerUser(ActionEvent event) {
        String nom = pnom.getText();
        String prenom = pprenom.getText();
        String email = pemail.getText();
        String motDePasse = pmotdepasse.getText();
        String confirmMotDePasse = pconfirmmotdepasse.getText();
        String numeroTelephone = pnumerotelephone.getText();
        String genre = pgenre.getValue();

        // Check if the password and confirm password match
        if (!motDePasse.equals(confirmMotDePasse)) {
            pErrorMessage.setText("Les mots de passe ne correspondent pas.");
            return;
        }

        boolean isClient = pclient.isSelected();
        boolean isGuide = pguide.isSelected();

        // Create a User object
        User newUser = new User(nom, prenom, email, motDePasse, numeroTelephone, "", genre, isClient ? UserRole.CLIENT : UserRole.GUIDE);

        // Save the user to the database
        userCRUD.ajouterUtilisateur(newUser);

        // Display a success message or handle errors as needed
        pErrorMessage.setText("Utilisateur enregistré avec succès.");
    }
}
