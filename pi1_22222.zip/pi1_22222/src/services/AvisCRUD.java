/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Avis;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import Utils.MyConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ghofr
 */
public class AvisCRUD {
   private List<Avis> listeAvis;
private Connection cnx = MyConnection.getInstance().getCnx();
    public AvisCRUD() {
        listeAvis = new ArrayList<>();
    }

    public void ajouterAvis(Avis avis) {
    
    try {
        String requete = "INSERT INTO Avis (Auteur, Note, Contenu) VALUES (?, ?, ?)";
        PreparedStatement pst = cnx.prepareStatement(requete);
        pst.setString(1, avis.getAuteur());
        pst.setInt(2, avis.getNote());
        pst.setString(3, avis.getContenu());
        pst.executeUpdate();
        System.out.println("Avis ajouté avec succès !");
    } catch (SQLException ex) {
        Logger.getLogger(AvisCRUD.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println(ex.getMessage());
    }
    }
    
    public Avis rechercherAvisParId(int id) {
        try {
            String requete = "SELECT * FROM Avis WHERE idAvis = ?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new Avis(rs.getInt("idAvis"), rs.getString("Auteur"), rs.getInt("Note"), rs.getString("Contenu"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(AvisCRUD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
        return null; // Avis non trouvé
    }
 public List<Avis> rechercherTousLesAvis() {
        List<Avis> listeAvis = new ArrayList<>();
        try {
            String requete = "SELECT * FROM Avis";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Avis avis = new Avis(rs.getInt("idAvis"), rs.getString("Auteur"), rs.getInt("Note"), rs.getString("Contenu"));
                listeAvis.add(avis);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AvisCRUD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
        return listeAvis;
    }
   public void modifierAvis(Avis avis) {
        try {
            String requete = "UPDATE Avis SET Auteur=?, Note=?, Contenu=? WHERE idAvis=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1, avis.getAuteur());
            pst.setInt(2, avis.getNote());
            pst.setString(3, avis.getContenu());
            pst.setInt(4, avis.getIdAvis());
            pst.executeUpdate();
            System.out.println("Avis modifié avec succès !");
        } catch (SQLException ex) {
            Logger.getLogger(AvisCRUD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
    }

    public void supprimerAvis(int id) {
        try {
            String requete = "DELETE FROM Avis WHERE idAvis = ?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, id);
            int rowsDeleted = pst.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Avis supprimé avec succès !");
            } else {
                System.out.println("Avis non trouvé avec l'ID " + id);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AvisCRUD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
    } 
}
