 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.*;
import java.util.UUID;
/**
 *
 * @author ghofr
 */
public class CodePromo {
 private int idcp;
    private String code;
    private String description;
    private double valeur;
    private boolean estValide;

   public CodePromo() {
        // Constructeur par défaut
        this.code = genererCodeUnique();
    }
    private String genererCodeUnique() {
        // Générer un code unique en utilisant UUID
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    public CodePromo(String code, String description, double valeur, boolean estValide) {
        this.code = code;
        this.description = description;
        this.valeur = valeur;
        this.estValide = estValide;
    }

    public int getIdcp() {
        return idcp;
    }

    public void setIdcp(int idcp) {
        this.idcp = idcp;
    }

   

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getValeur() {
        return valeur;
    }

    public void setValeur(double valeur) {
        this.valeur = valeur;
    }

    public boolean isEstValide() {
        return estValide;
    }

    public void setEstValide(boolean estValide) {
        this.estValide = estValide;
    }

    @Override
    public String toString() {
        return "CodePromo{" + "idcp=" + idcp + ", code=" + code + ", description=" + description + ", valeur=" + valeur + ", estValide=" + estValide + '}';
    }

    
     
}
